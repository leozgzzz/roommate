// In js/signup.js
document.getElementById('signupForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const budget = document.getElementById('budget').value;
    const lifestyle = document.getElementById('lifestyle').value;
    const ageRange = document.getElementById('ageRange').value;
  
    const response = await fetch('/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, email, password, preferences: { budget, lifestyle, ageRange } })
    });
  
    if (response.ok) {
      alert('Signup successful!');
    } else {
      alert('Error during signup');
    }
  });
  