document.getElementById('user-profile-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    fetch('/upload-profile-picture', {
      method: 'POST',
      body: formData,
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
          console.log('Profile created:', data);
          addProfileCard(data.user);
      } else {
          console.error('Failed to create profile:', data);
          alert('Failed to create profile.');
      }
    })
    .catch(error => {
      console.error('Error creating profile:', error);
      alert('Error creating profile: ' + error.message);
    });
  });
  
  function addProfileCard(user) {
    const container = document.querySelector('.container');
    const cardHTML = `
        <div class="card">
            <img src="${user.imageUrl}" alt="Profile Picture" class="profile-img">
            <h2>${user.name}</h2>
            <p>${user.age} YRS, ${user.profession}</p>
            <p>Budget: ${user.budget}</p>
            <p>Looking in ${user.location}</p>
            <button>Contact</button>
        </div>
    `;
    container.innerHTML += cardHTML;
  }

  app.use(express.static(path.join(__dirname, 'public')));
