from flask import Flask, request, jsonify
import cx_Oracle
import os

app = Flask(__name__)

# Oracle database connection string: username/password@hostname:port/service_name
# Replace placeholders with your actual database connection details
DATABASE_URL = "username/password@localhost:1521/xe"

# Ensure Oracle client libs are in PATH or use:
# cx_Oracle.init_oracle_client(lib_dir=r'/path/to/instantclient_19_8')

@app.route('/signup', methods=['POST'])
def signup():
    username = request.json['username']
    email = request.json['email']
    password = request.json['password']  # In production, use password hashing
    
    conn = cx_Oracle.connect(DATABASE_URL)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)",
            [username, email, password]
        )
        conn.commit()
    except cx_Oracle.DatabaseError as e:
        return jsonify({'message': 'Signup failed', 'error': str(e)}), 400
    finally:
        cursor.close()
        conn.close()
    
    return jsonify({'message': 'Signup successful'}), 201

@app.route('/login', methods=['POST'])
def login():
    email = request.json['email']
    password = request.json['password']  # In production, verify hashed password
    
    conn = cx_Oracle.connect(DATABASE_URL)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT * FROM users WHERE email = :email AND password = :password",
            [email, password]
        )
        user = cursor.fetchone()
        if user:
            return jsonify({'message': 'Login successful', 'user': user[1]}), 200
        else:
            return jsonify({'message': 'Invalid credentials'}), 401
    finally:
        cursor.close()
        conn.close()
    
    return jsonify({'message': 'Login failed'}), 400

if __name__ == '__main__':
    app.run(debug=True)
