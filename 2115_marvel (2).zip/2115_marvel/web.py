import requests
from bs4 import BeautifulSoup

# URL of the webpage you want to scrape
url = 'https://tfc.com/new-york-luxury-no-fee-apartments'

# Send an HTTP request to the URL
response = requests.get(url)

# Parse the HTML content of the page with BeautifulSoup
soup = BeautifulSoup(response.text, 'html.parser')

# Find and print the page title
title = soup.find('title').text
print('Page Title:', title)
