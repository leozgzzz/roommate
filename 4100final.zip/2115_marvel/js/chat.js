const questions = [
    { text: "What's your move-in date?", inputType: "date", options: [] },
    { text: "What's your budget?", inputType: "select", options: ["0-1000", "1000-2000", "2000-3000", "over 3000"] },
    { text: "Do you have pets?", inputType: "select", options: ["Yes", "No"] },
    { text: "What area are you interested in?", inputType: "select-multiple", options: ["Uptown", "Midtown", "Downtown", "Long Island City"] }
];

let currentQuestion = 0;

function displayQuestion() {
    const chat = document.getElementById('messages');
    const userInput = document.getElementById('userInput');
    userInput.innerHTML = ''; // Clear previous inputs

    const question = questions[currentQuestion];

    chat.innerHTML += `<div>${question.text}</div>`;

    if (question.inputType === "date") {
        const input = document.createElement('input');
        input.type = 'date';
        userInput.appendChild(input);
        setupNextButton(() => saveAnswer(input.value));
    } else if (question.inputType === "select" || question.inputType === "select-multiple") {
        const select = document.createElement('select');
        if (question.inputType === "select-multiple") {
            select.multiple = true;
            select.size = question.options.length;
        }
        question.options.forEach(option => {
            const opt = document.createElement('option');
            opt.value = option;
            opt.innerHTML = option;
            select.appendChild(opt);
        });
        userInput.appendChild(select);
        setupNextButton(() => saveMultipleChoiceAnswers(select));
    }
}

function setupNextButton(onClickAction) {
    const userInput = document.getElementById('userInput');
    const button = document.createElement('button');
    button.textContent = 'Next';
    button.onclick = onClickAction;
    userInput.appendChild(button);
}

function saveMultipleChoiceAnswers(select) {
    const answers = Array.from(select.selectedOptions).map(opt => opt.value).join(", ");
    saveAnswer(answers);
}

function saveAnswer(answer) {
    const chat = document.getElementById('messages');
    chat.innerHTML += `<div>Your answer: ${answer}</div>`;
    console.log(`Question: ${questions[currentQuestion].text}, Answer: ${answer}`); // Log the answer for reference
    currentQuestion++;
    displayQuestion();
}

function startChat() {
    displayQuestion();
}

document.addEventListener('DOMContentLoaded', function() {
    startChat(); // Automatically start the chat when the page loads
});

document.addEventListener('DOMContentLoaded', function() {
    const toggler = document.querySelector('.chatbot-toggler');
    const chatbot = document.querySelector('.chatbot');
    const closeBtn = chatbot.querySelector('.close-btn');
  
    toggler.addEventListener('click', () => {
      chatbot.style.display = chatbot.style.display === 'none' ? 'block' : 'none';
    });
  
    closeBtn.addEventListener('click', () => {
      chatbot.style.display = 'none';
    });
  });
  