var map;
var markers = [];

function initMap() {
  map = new google.maps.Map(document.getElementById('map'), {
    center: { lat: 40.748817, lng: -73.985428 }, // Default center (New York City)
    zoom: 13
  });
  fetchListingsAndCreateMarkers();
}

async function fetchListingsAndCreateMarkers() {
  const response = await fetch('http://localhost:3000/listings');
  const listings = await response.json();
  const listingsContainer = document.querySelector('.listings');
  listingsContainer.innerHTML = '';

  listings.forEach(async (listing, index) => { // Use async here for geocoding
    const { imageUrl, title, neighborhood, price, href, details, aptNumber, lat, lng } = listing;

    const listingElement = document.createElement('div');
    listingElement.className = 'listing card';
    listingElement.id = `listing-${index}`;
    listingElement.innerHTML = `
      <img src="${imageUrl}" alt="${title}">
      <div class="card-body">
        <h3>${title}</h3>
        <p class="price">${price}</p>
        <p class="neighborhood">${neighborhood}</p>
        <p class="apt-number">Apt #${aptNumber || 'unavailable'}</p>
        <p class="details">${details}</p>
        <a href="${href}" class="view-details">View Details</a> 
      </div>
    `;
    listingsContainer.appendChild(listingElement);

    const address = `${listing.title}, ${listing.neighborhood}, New York, NY`; 


    // Geocoding and Marker Creation
    if (!listing.lat || !listing.lng) {
      const coordinates = await getCoordinates(address); // I assume the address is in `title`.
      if (coordinates) {
        listing.lat = coordinates.lat;
        listing.lng = coordinates.lng;
      }
    }
    createMarker(listing, listingElement, index, listings);
  });
}

function createMarker(listing, listingElement, index, listings) {
  const marker = new google.maps.Marker({
    position: { lat: listing.lat, lng: listing.lng },
    map: map,
    title: listing.title
  });
  markers.push(marker);

  marker.addListener('click', () => {
    highlightListingCard(index, listings);
    map.panTo(marker.getPosition());
    map.setZoom(15);
  });

  listingElement.marker = marker; // Store marker reference
}

function highlightListingCard(listingIndex, listingsData) {
  // Remove highlighting from all listings
  listingsData.forEach((_, index) => {
    const element = document.getElementById(`listing-${index}`);
    if (element) {
      element.classList.remove('highlighted-listing');
    }
  });

  // Highlight the listing corresponding to the clicked marker
  const highlightedElement = document.getElementById(`listing-${listingIndex}`);
  if (highlightedElement) {
    highlightedElement.classList.add('highlighted-listing');
    highlightedElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

  

async function getCoordinates(address) {
    const apiKey = 'AIzaSyDoisyQ_fATZGaV0GxZR6OCZChmZkuat88'; // Replace with your actual API key
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${apiKey}`;
    console.log(`Attempting to geocode address: "${address}"`); // Log the address being queried

    try {
      const response = await fetch(url);
      const data = await response.json();
  
      if (data.status === 'OK') {
        const location = data.results[0].geometry.location;
        return { lat: location.lat, lng: location.lng };
      } else {
        console.error('Geocoding failed:', data.status);
        return null;
      }
    } catch (error) {
      console.error('Error fetching geocoding data:', error);
      return null;
    }
  }
