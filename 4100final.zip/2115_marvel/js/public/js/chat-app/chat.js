import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import '';

const socket = io('http://localhost:3000'); // Ensure this matches your server address

function Chat() {
    const [message, setMessage] = useState('');
    const [chat, setChat] = useState([]);

    useEffect(() => {
        socket.on('message', (msg) => {
            setChat([...chat, msg]);
        });

        // Cleanup to prevent memory leaks
        return () => {
            socket.off('message');
        };
    }, [chat]);

    const sendChat = (e) => {
        e.preventDefault();
        socket.emit('sendMessage', message);
        setMessage('');
    };

    return (
        <div className="chat-container">
            <h1>Chat Room</h1>
            <div className="messages">
                {chat.map((msg, index) => (
                    <p key={index}>{msg}</p>
                ))}
            </div>
            <form onSubmit={sendChat} className="message-form">
                <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type a message..."
                />
                <button type="submit">Send</button>
            </form>
        </div>
    );
}

export default Chat;
