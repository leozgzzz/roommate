
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const puppeteer = require('puppeteer');
const cron = require('node-cron');
const app = express();


app.use(bodyParser.json());
app.use(cors());

// MongoDB setup (Ensure this is configured correctly with your actual credentials)
mongoose.connect('mongodb+srv://zl4457:Lzg99128@user.hnuvnqb.mongodb.net/', {
  useNewUrlParser: true, 
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.log('Error connecting to MongoDB:', err));

// Define your user schema and model here
// In server.js or a separate models/user.js file

const UserSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  preferences: {
    budget: Number,
    location: String,
    lifestyle: String,
    ageRange: String
  }
});
const User = mongoose.model('User', UserSchema);

const RoommateProfileSchema = new mongoose.Schema({
  name: String,
  age: Number,
  profession: String,
  budget: String,
  location: String,
  imageUrl: String  // URL to the uploaded image
});
const RoommateProfile = mongoose.model('RoommateProfile', RoommateProfileSchema);

// Configure Multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/') // Simplified path, assuming 'uploads/' is under your project root
  },
  filename: function(req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


const upload = multer({
  storage: multer.diskStorage({
      destination: function (req, file, cb) {
          cb(null, 'uploads/') // Make sure this directory exists
      },
      filename: function (req, file, cb) {
          const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
          cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname))
      }
  }),
  fileFilter: function (req, file, cb) {
      if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
          return cb(new Error('Only image files are allowed!'), false);
      }
      cb(null, true);
  },
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB file size limit
});

app.post('/upload-profile-picture', upload.single('profile-picture'), (req, res) => {
  // Assuming everything goes well, send back some information including the file path
  res.json({ success: true, path: req.file.path });
});

app.post('/create-profile', upload.single('profile-picture'), async (req, res) => {
  try {
      const { name, age, profession, budget, location } = req.body;
      const imageUrl = req.file ? `/uploads/${req.file.filename}` : ''; // Ensure this is a relative URL

      const newProfile = new RoommateProfile({
          name, age, profession, budget, location, imageUrl
      });
      await newProfile.save();
      res.status(201).json({ success: true, user: newProfile });
  } catch (error) {
      console.error("Error creating profile:", error);
      res.status(500).send("Error creating profile");
  }
});








// Environment variables for JWT
const JWT_SECRET = process.env.JWT_SECRET || 'your_secret_key'; // Set this in your .env file

// Signup API Endpoint
app.post('/signup', async (req, res) => {
  try {
    const { username, email, password, preferences } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, email, password: hashedPassword, preferences });
    await newUser.save();
    res.status(201).send('User created successfully');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Login API Endpoint
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).send('User not found');
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).send('Invalid credentials');
    }
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1d' });
    res.status(200).json({ token, email: user.email });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Profile picture upload endpoint

// Function to fetch listings and geocode them
const fetchListings = async () => {
  const baseUrl = 'https://tfc.com'; // Base URL of the website
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  try {
    await page.goto(baseUrl + '/new-york-luxury-no-fee-apartments', { waitUntil: 'networkidle0' });
    const listings = await page.evaluate((baseUrl) => {
      const listingElements = Array.from(document.querySelectorAll('a.tile'));
      return listingElements.map(el => {
        const title = el.querySelector('h2.tile-title')?.innerText.trim();
        const neighborhood = el.querySelector('span.heading-4')?.innerText.trim();
        const details = el.querySelector('span.tile-title:not(.heading-3)')?.innerText.trim();
        const price = el.querySelector('span.tile-subtitle')?.innerText.trim();
        let href = el.getAttribute('href');
        if (href && !href.startsWith('http')) {
          href = baseUrl + (href.startsWith('/') ? '' : '/') + href; // Ensure href is an absolute URL
        }
        const imageUrlStyle = el.querySelector('div.tile-image')?.style.backgroundImage;
        const imageUrl = imageUrlStyle?.match(/url\(['"]?(.*?)['"]?\)/i)[1];

        const aptNumberSpan = el.querySelector('.tile-footer span:first-child');
        const aptNumber = aptNumberSpan ? aptNumberSpan.innerText.trim().replace(/^#/, '') : null;

        console.log(`Apartment Number Extracted: ${aptNumber}`); // Debug output

        return {
          title,
          neighborhood,
          details,
          price,
          href,
          imageUrl,
          aptNumber
        };
      });
    }, baseUrl);
    return listings;
  } finally {
    await browser.close();
  }
};

app.get('/listings', async (req, res) => {
  try {
    const listings = await fetchListings();
    res.json(listings);
  } catch (error) {
    console.error('Failed to fetch listings:', error);
    res.status(500).send('Failed to fetch listings');
  }
});

// Optionally, scheduled task to refresh listings every 4 hours
cron.schedule('0 */4 * * *', async () => {
  console.log('Fetching updated listings...');
  const listings = await fetchListings();
  console.log('Updated listings:', listings);
});



const userSchema = new mongoose.Schema({
  name: String,
  age: Number,
  profession: String,
  budget: String,
  location: String,
  imageUrl: String  // URL to the uploaded image
});

app.get('/api/profiles', async (req, res) => {
  try {
      const profiles = await RoommateProfile.find();
      console.log('Retrieved profiles:', profiles);  // Log retrieved profiles
      res.json(profiles);
  } catch (error) {
      console.error('Error fetching profiles:', error);
      res.status(500).json({ message: 'Error fetching profiles', error: error });
  }
});

app.post('/submit-form', async (req, res) => {
  try {
      const { name, email, message } = req.body;
      // Assuming you have a MongoDB model set up to store the form data
      const FormData = mongoose.model('FormData', new mongoose.Schema({
          name: String,
          email: String,
          message: String
      }));
      const newFormData = new FormData({ name, email, message });
      await newFormData.save();
      res.send('Form data submitted successfully!');
  } catch (error) {
      console.error('Failed to submit form data:', error);
      res.status(500).send('Failed to submit form data');
  }
});



const chatResponseSchema = new mongoose.Schema({
  responses: [{
    question: String,
    answer: String
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  sessionId: String  // Optional, if you want to track sessions
});

const ChatResponse = mongoose.model('ChatResponse', chatResponseSchema);

app.post('/submit-chat-response', async (req, res) => {
  try {
    const { responses, sessionId } = req.body;  // sessionId is optional
    const newChatResponse = new ChatResponse({ responses, sessionId });
    await newChatResponse.save();
    res.status(201).json({ success: true, message: "Responses saved successfully" });
  } catch (error) {
    console.error('Failed to save chat responses:', error);
    res.status(500).send('Failed to save chat responses');
  }
});



  




const PORT = process.env.PORT || 3000;
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));
app.listen(PORT, () => {
  console.log(`Server listening at http://localhost:${PORT}`);
});