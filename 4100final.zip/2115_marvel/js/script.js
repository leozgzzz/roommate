document.getElementById('filter-btn').addEventListener('click', function() {
    const locationInput = document.getElementById('location-input').value.toLowerCase();
    const budgetSelect = document.getElementById('budget-select').value;
    const ageRangeSelect = document.getElementById('age-range-select').value;
    const profileSelect = document.getElementById('profile-select').value;

    const cards = document.querySelectorAll('.card');
    console.log("Found cards:", cards.length);

    cards.forEach(card => {
        const profileDetails = card.querySelectorAll('p');
        console.log("Card details:", Array.from(profileDetails).map(p => p.textContent));

        let isVisible = true;

        // Extract and filter by budget
        const budgetText = profileDetails[2].textContent; // The budget is in the third <p> tag
        console.log("Budget Text:", budgetText); // Add this to check the actual text content

        const budgetRegex = /Budget: \$?([0-9,]+)/i; // Regex to extract numeric value following "Budget: $"
        const match = budgetText.match(budgetRegex);
        const budgetValue = match ? parseInt(match[1].replace(/,/g, '')) : null;

        console.log("Extracted budget value:", budgetValue); // Check what value is extracted

        if (budgetSelect && budgetValue !== null) {
            const [minBudget, maxBudget] = budgetSelect.split('-').map(Number);
            console.log("Comparing against budget range:", minBudget, maxBudget);
            if (budgetValue < minBudget || budgetValue > maxBudget) {
                isVisible = false;
            }
        }

        // Filter by age range
        if (ageRangeSelect) {
            const [minAge, maxAge] = ageRangeSelect.split('-');
            const age = parseInt(profileDetails[0].textContent.split(' ')[0]); // Assuming age is in the first <p>
            if (age < parseInt(minAge) || age > parseInt(maxAge)) {
                isVisible = false;
            }
        }

        // Filter by profile type
        const profileType = profileDetails[1].textContent.toLowerCase();
    
    // Check if a profile type is selected and handle "Other" category
    if (profileSelect) {
        if (profileSelect === "other") {
            // Show the card if the profile type is not 'student' or 'professional'
            if (profileType.includes("student") || profileType.includes("professional")) {
                isVisible = false;
            }
        } else {
            // Standard behavior for 'student' and 'professional'
            if (!profileType.includes(profileSelect)) {
                isVisible = false;
            }
        }
    }

    // Set visibility based on the above logic
    card.style.display = isVisible ? 'block' : 'none';
});
    
    document.getElementById('reset-btn').addEventListener('click', function() {
        // Clear all filter inputs
        document.getElementById('location-input').value = '';
        document.getElementById('date-listed-select').value = '';
        document.getElementById('budget-select').value = '';
        document.getElementById('age-range-select').value = '';
        document.getElementById('profile-select').value = '';
    
        // Reset the display of all cards
        const cards = document.querySelectorAll('.card');
        cards.forEach(card => {
            card.style.display = 'block'; // Show all cards
        });
    });
    

    
    document.getElementById('user-profile-form').addEventListener('submit', function(event) {
        event.preventDefault(); // Stop the form from submitting normally
    
        // 'this' now correctly refers to the form element
        const formData = new FormData(this);
        const profileData = {
            name: formData.get('name'),
            age: formData.get('age'),
            profession: formData.get('profession'),
            budget: formData.get('budget'),
            location: formData.get('location'),
            profilePicture: formData.get('profile-picture')
        };
    
        // Function to handle the creation of the profile
        createProfile(formData);
    });
    
    });
    
    function saveProfileToLocalStorage(profileData) {
        let profiles = JSON.parse(localStorage.getItem('profiles')) || [];
        profiles.push(profileData); // Add the new profile
        localStorage.setItem('profiles', JSON.stringify(profiles)); // Save back to Local Storage
    }
    
    document.getElementById('user-profile-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(this);
    
        const profileData = {
            name: formData.get('name'),
            age: formData.get('age'),
            profession: formData.get('profession'),
            budget: formData.get('budget'),
            location: formData.get('location'),
            gender: formData.get('gender'),
            sexualOrientation: formData.get('sexual-orientation'),
            image: '',
            email: formData.get('email'), // Make sure you're getting these from the form
            phone: formData.get('phone')  // This will be set after the file is read
        };
    
        const reader = new FileReader();
        reader.onload = function(event) {
            profileData.image = event.target.result; // Set the image URL for display
            createProfileCard(profileData);
            saveProfileToLocalStorage(profileData);
            document.getElementById('user-profile-form').reset();
        };
        reader.readAsDataURL(formData.get('profile-picture'));
    });
    
    
    function createProfileCard(profileData, index) {
        const container = document.querySelector('.container');
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <img src="${profileData.image}" class="profile-img" alt="Profile Picture">
            <h2>${profileData.name}</h2>
            <p>${profileData.age} YRS, ${profileData.gender}</p>
            <p>${profileData.profession}</p>
            <p>Budget: ${profileData.budget}</p>
            <p>Sexual Orientation: ${profileData.sexualOrientation}</p>
            <p>Looking in ${profileData.location}</p>
            <button class="delete-btn">Delete</button>
            <button class="contact-btn">Contact</button>
        `;
        container.appendChild(card);
    
        // Delete button event listener
        const deleteBtn = card.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', () => {
            deleteProfile(index);
            container.removeChild(card);
        });
    
        // Contact button event listener
        const contactBtn = card.querySelector('.contact-btn');
        if (contactBtn) {
            contactBtn.addEventListener('click', () => {
                document.getElementById('contact-email').textContent = profileData.email;
                document.getElementById('contact-phone').textContent = profileData.phone;
                document.getElementById('contact-info-dialog').style.display = 'flex'; // Display the dialog
            });
        }
    }

    function deleteProfile(index) {
        let profiles = JSON.parse(localStorage.getItem('profiles')) || [];
        profiles.splice(index, 1); // Remove the profile at the given index
        localStorage.setItem('profiles', JSON.stringify(profiles)); // Save the updated array back to Local Storage
    }
    
    

    
    // Load profiles from Local Storage when the page loads
    document.addEventListener('DOMContentLoaded', function() {
        const profiles = JSON.parse(localStorage.getItem('profiles')) || [];
        profiles.forEach((profile, index) => createProfileCard(profile, index));
    });
    
    

    
    
        // Extract data from the form
        const formData = new FormData(this);
        const profileData = {
            name: formData.get('name'),
            age: formData.get('age'),
            profession: formData.get('profession'),
            budget: formData.get('budget'),
            location: formData.get('location'),
            profilePicture: formData.get('profile-picture')
        };
    
        // Assuming you have a function to handle the API request
        createProfile(profileData);
    
        function createProfile(formData) {
            fetch('http://localhost:3000/create-profile', {
                method: 'POST',
                body: formData,  // Assuming formData includes the file for 'profile-picture'
            })
            .then(response => response.json())
            .then(data => {
                console.log('Server response:', data);  // Log the entire server response
                if (data && data.user) {
                    addProfileToPage(data.user);
                } else {
                    console.error('User data is missing in the response', data);
                }
            })
            .catch((error) => {
                console.error('Error during profile creation:', error);
            });
        }
        
        
    
    
    function addProfileToPage(user) {
        const container = document.querySelector('.container');
        const newCard = document.createElement('div');
        newCard.className = 'card';
        newCard.innerHTML = `
            <img src="${user.imageUrl}" alt="Profile Picture" class="profile-img">
            <h2>${user.name}</h2>
            <p>${user.age} YRS</p>
            <p>${user.profession}</p>
            <p>Budget: ${user.budget}</p>
            <p>Looking in ${user.location}</p>
            <button>Contact</button>
        `;
        container.appendChild(newCard);
    }

    // This function will be called when the page loads
    function fetchAndDisplayProfiles() {
        fetch('/api/profiles')
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to fetch profiles');
            }
            return response.json();
        })
        .then(profiles => {
            console.log('Received profiles:', profiles); // Check the data in the console
            const container = document.querySelector('.container');
            profiles.forEach(profile => {
                const cardHtml = `
                    <div class="card">
                        <img src="${profile.imageUrl}" alt="Profile Picture" class="profile-img">
                        <h2>${profile.name}</h2>
                        <p>${profile.age} YRS</p>
                        <p>${profile.profession}</p>
                        <p>Budget: ${profile.budget}</p>
                        <p>Looking in ${profile.location}</p>
                        <button>Contact</button>
                    </div>
                `;
                container.innerHTML += cardHtml;
            });
        })
        .catch(error => {
            console.error('Error fetching profiles:', error);
        });
    }

    function closeDialog() {
        document.getElementById('contact-info-dialog').style.display = 'none';
    }
    
    // This will close the dialog if the X button is clicked
    document.querySelector('.close-button').addEventListener('click', closeDialog);
    
    // Optional: Close the dialog if anywhere outside of the dialog content is clicked
    window.onclick = function(event) {
        const dialog = document.getElementById('contact-info-dialog');
        if (event.target === dialog) {
            closeDialog();
        }
    }
    


    
// Call this function when the page loads
document.addEventListener('DOMContentLoaded', fetchAndDisplayProfiles);

    
